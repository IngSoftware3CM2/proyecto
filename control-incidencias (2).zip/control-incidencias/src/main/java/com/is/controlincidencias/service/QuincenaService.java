package com.is.controlincidencias.service;

import java.time.LocalDate;

public interface QuincenaService {
    int idquincenaConFechaDeIncidencia(LocalDate fecha);
}
