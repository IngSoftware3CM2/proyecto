package com.is.controlincidencias.service;

import com.is.controlincidencias.entity.Zona;

public interface ZonaService {
    public Zona getZonabyNombre(String nombre);
}
