package com.is.controlincidencias.model;

public class ConsultaUnidadMedica {
    private String idUnidadMedica;
    private String nameUnidadMedica;

    public String getIdUnidadMedica() {
        return idUnidadMedica;
    }

    public void setIdUnidadMedica(String idUnidadMedica) {
        this.idUnidadMedica = idUnidadMedica;
    }

    public String getNameUnidadMedica() {
        return nameUnidadMedica;
    }

    public void setNameUnidadMedica(String nameUnidadMedica) {
        this.nameUnidadMedica = nameUnidadMedica;
    }
}
