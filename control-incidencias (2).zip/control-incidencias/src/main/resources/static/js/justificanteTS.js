$(document).ready(function () {
    $("#buttonCancelar").on("click",function(){
        window.location.href="/personal/justificantes/tiemposuplementario/cancelar";
    });
})