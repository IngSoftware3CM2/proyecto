package com.is.controlincidencias.service;

import com.is.controlincidencias.model.DepartamentoForm;

import java.util.List;

public interface UsuariosService {
    List<DepartamentoForm> recuperarDepartamentos();
}
